﻿Public Class Form1

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        MsgBox("Program By Ahmed Wolf")
        On Error Resume Next
        WebBrowser1.Navigate("https://www.facebook.com/login")
        WebBrowser1.ScriptErrorsSuppressed = True
        Button4.Hide()

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
       

    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
       


    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
      
    End Sub

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        On Error Resume Next

        ListBox1.SelectedIndex += 1
        WebBrowser1.Document.GetElementById("email").SetAttribute("value", TextBox1.Text)
        WebBrowser1.Document.GetElementById("pass").SetAttribute("value", TextBox2.Text)
        WebBrowser1.Document.GetElementById("loginbutton").InvokeMember("click")

    End Sub

    Private Sub RadioButton1_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub RadioButton2_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub RadioButton3_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub Timer2_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer2.Tick
        TextBox2.Text = ListBox1.SelectedItem
        TextBox3.Text = WebBrowser1.DocumentTitle
        If TextBox3.Text = "Login Help" Then
            WebBrowser1.Navigate("https://www.facebook.com/login")
            Timer2.Stop()
        End If
        If TextBox3.Text = "Help For Login FaceBook" Then
            WebBrowser1.Navigate("https://www.facebook.com/login")
            Timer2.Stop()
        End If

    End Sub

    Private Sub Timer3_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer3.Tick
        If TextBox3.Text = "Login Help" Then
            Timer2.Start()
        End If
        If TextBox3.Text = "Help For Login FaceBook" Then
            Timer2.Start()
        End If

    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Form2.Show()

    End Sub

    Private Sub Button1_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim openfile As New OpenFileDialog
        ListBox1.Items.Clear()
        openfile.Title = "Text |*.txt"
        openfile.ShowDialog()
        Dim txtline() As String = IO.File.ReadAllLines(openfile.FileName)
        ListBox1.Items.AddRange(txtline)
        MsgBox("Kamus di tambahkan pada aplikasi")
    End Sub

    Private Sub Button2_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Timer1.Start()
        Timer3.Start()
        Timer2.Start()
        Button4.Show()
    End Sub

    Private Sub Button4_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        Timer1.Stop()
        Timer3.Stop()
        Timer2.Stop()
        Button4.Hide()
    End Sub

    Private Sub RadioButton1_CheckedChanged_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RadioButton1.CheckedChanged
        Timer1.Interval = 4000
    End Sub

    Private Sub RadioButton2_CheckedChanged_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RadioButton2.CheckedChanged
        Timer1.Interval = 5000
    End Sub

    Private Sub RadioButton3_CheckedChanged_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RadioButton3.CheckedChanged
        Timer1.Interval = 6000
    End Sub

    Private Sub TextBox3_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox3.TextChanged

    End Sub
End Class
